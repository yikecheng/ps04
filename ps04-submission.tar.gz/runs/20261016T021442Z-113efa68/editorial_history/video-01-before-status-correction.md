# The shift: agents are entering the delivery control plane

**Publication:** Agent Signal  
**Evidence cut-off:** 2026-10-16  
**Target runtime:** 4:00–4:30  
**Approximate spoken words:** 620

## Scene 1 — The real change

**Narration**

<!-- claim:01-c8 -->
The important shift is not proof that coding agents can work unattended. Across Cursor’s rollout controls, GitHub’s draft security-fix pull requests, and Spotify’s failure case, the production-ready advance is more specific: agents are entering workflows with editable plans, human approval, staged rollout, and rollback. That is a multi-source inference, not a measured reliability rate. The agent is becoming a governable participant in delivery—not a self-certifying engineer.

**Visual direction**

[VISUAL: Animate a delivery pipeline labeled Code → Review → Security → Deploy → Monitor. Place an agent icon inside the pipeline, surrounded by approval, test, and rollback gates. End on: “Governable participation ≠ unattended correctness.”]

[VISUAL: On-screen disclosure for five seconds: “AI assisted research, drafting, and presentation; human editorial review completed.”]

**Source notes — video 0:00–0:35**

This inference combines Cursor’s rollout workflow, GitHub’s draft-PR workflow, and Spotify’s reported production incident.

## Scene 2 — Agents move beyond code generation

**Narration**

<!-- claim:01-c1 -->
Cursor says Rollouts, available on Teams and Enterprise plans, reads a diff before merge and writes a monitoring plan. A person can edit that plan. After deployment, configuration can ping the author, pause a progressive rollout, or prepare a revert pull request that waits for approval.

<!-- claim:01-c2 -->
GitHub’s generally available agentic autofix for eligible security customers explores relevant repository files, proposes a repair, reruns CodeQL, and opens a draft pull request for human review. The useful unit is not autonomous repair; it is a proposed, machine-checked change inside the existing review system.

<!-- claim:01-c3 -->
OpenAI’s code-review demonstration shows that, once a connector has the required repository permissions, an initial pull-request review can run automatically. The demonstration establishes workflow feasibility, not review accuracy.

**Visual direction**

[VISUAL: Three-column diagram. Cursor: diff → editable monitoring plan → gated revert. GitHub: alert → files → CodeQL → draft PR. OpenAI: connector permissions → automatic first review. Use source-title cards, not product footage.]

**Source notes — video 0:35–1:40**

Cursor and GitHub are vendor release accounts. OpenAI media evidence appears at source timestamps 0:41–0:45 and 0:47–0:49.

## Scene 3 — Harnesses and controls are part of the capability

**Narration**

<!-- claim:01-c4 -->
Cursor separately reports that changes to its agent harness reduced users’ token costs by seven percent without reducing agent quality. Cursor tracked cost, latency, tool errors, and usage, but this remains an internal vendor result rather than an independent benchmark.

<!-- claim:01-c7 -->
At much larger scale, InfoQ relays GitHub’s report of an AI-assisted rewrite exceeding 800,000 production lines. It took about 14.5 weeks and 128 pull requests while releases continued. Agents produced most of the implementation, while compilation, testing, and human review exposed regressions involving behavior, state, library semantics, and lost optimizations.

Together, these reports suggest that context assembly, testing, and review infrastructure are part of the practical capability—not administrative extras.

**Visual direction**

[VISUAL: Split screen. Left: token meter drops 7%, tagged “Cursor internal result.” Right: 128 PR cards move incrementally across a TypeScript-to-Rust bridge while test and review gates catch red regression markers.]

**Source notes — video 1:40–2:30**

Use Cursor’s harness report and InfoQ’s account of GitHub’s migration. Both ultimately rely on company-reported measurements.

## Scene 4 — Scale does not erase production risk

**Narration**

<!-- claim:01-c5 -->
InfoQ also reports that Spotify’s monthly merged changes grew from roughly 8,100 to 17,000 year over year in August. That is a notable throughput signal, but it is not an autonomous-correctness measure.

<!-- claim:01-c6 -->
The same Spotify account includes the counterexample: an automated dependency upgrade passed existing checks and then failed in production. Spotify subsequently strengthened safeguards, expanded rollback capacity, and scheduled automated changes during the owning teams’ working hours.

These cases are informative, not population estimates. Official releases establish availability and workflow scope, but not review accuracy, security-fix correctness, false-positive rates, latency, or return on investment. Cursor, GitHub, and OpenAI sell the featured products; their demonstrations are curated. The production cases reported by InfoQ also come from organizations far larger than a 2–20-person team.

**Visual direction**

[VISUAL: Line rises from 8,100 to 17,000, then changes into a warning card: “Checks passed → production failed.” Follow with three response cards: stronger safeguards, more rollback capacity, working-hours scheduling.]

**Source notes — video 2:30–3:30**

The Spotify figures and incident are company claims reported by InfoQ. One incident demonstrates possibility, not an error rate.

## Scene 5 — What a small team should do now

**Narration**

For a small team, the evidence supports a measured trial. Pick one bounded workflow with an external check: a CodeQL remediation, a deterministic migration step, or an initial review pass. Require a draft pull request and named human approver. Define deployment signals before merge, stage the rollout, and test the rollback path.

Record accepted outcomes, rework, reviewer time, failures after deployment, and the cost of running the agent. Expand only if your own results improve without shifting hidden work onto reviewers or operators.

The takeaway is deliberately narrow: current agents are credible participants in controlled delivery workflows. The supplied evidence does not justify unattended deployment or the assumption that passing today’s checks means production-safe behavior.

**Visual direction**

[VISUAL: Five-item checklist animates in: bounded task; external check; human approval; staged rollout; tested rollback. Close on the Agent Signal title and: “Trial the control system, not the autonomy story.”]

**Source notes — video 3:30–4:15**

This recommendation synthesizes the workflow controls and failure evidence; no supplied source tests the complete small-team adoption pattern end to end.

## Ready-to-paste companion-article copy

**Headline:** Coding agents are entering the delivery control plane

**Standfirst:** New releases place coding agents inside review, security remediation, deployment monitoring, and large migrations. The evidence supports bounded trials with external checks, approval, and rollback—not unattended software delivery.

**Callout:** The production-ready capability is governed participation in an existing engineering system.

## Ready-to-paste video-description copy

Coding agents are moving beyond code generation and into review, security remediation, rollout monitoring, and migration workflows. Agent Signal examines what Cursor, GitHub, OpenAI, and reported production cases actually establish—and why a Spotify failure keeps the conclusion narrow.

For small teams, the practical next step is a bounded pilot with external validation, human approval, staged deployment, and a tested rollback path. Evidence cut-off: October 16, 2026.

Disclosure: AI assisted research, drafting, and presentation; human editorial review completed.

## Sources

- Cursor — *Bots for the last mile* — 2026-09-23 — https://cursor.com/blog/rollouts-and-security-reviewer — Timestamp: n/a, text source.
- GitHub — *Agentic autofix for code scanning alerts general availability* — 2026-10-15 — https://github.blog/changelog/2026-10-15-agentic-autofix-for-code-scanning-alerts-general-availability — Timestamp: n/a, text source.
- OpenAI — *Code review is no longer the bottleneck* — 2026-10-12 — https://www.youtube.com/watch?v=IZXv6a78NDw — Timestamps: 0:41–0:45 and 0:47–0:49.
- Cursor — *Improved token efficiency for longer agent runs* — 2026-09-23 — https://cursor.com/blog/improved-token-efficiency — Timestamp: n/a, text source.
- InfoQ — *Spotify More Than Doubled Monthly Code Changes as AI Accelerated Development* — 2026-10-12 — https://www.infoq.com/news/2026/10/spotify-ai-quality-controls/ — Timestamp: n/a, text source.
- InfoQ — *Github Migrates Copilot Runtime to Rust with AI-Assisted Rewrite* — 2026-10-09 — https://www.infoq.com/news/2026/10/github-copilot-rust-migration/ — Timestamp: n/a, text source.
