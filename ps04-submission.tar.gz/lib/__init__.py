"""Shared pipeline infrastructure."""
